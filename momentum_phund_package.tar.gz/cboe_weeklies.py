"""
CBOE Weekly Options List - Fetches equity tickers with weekly options from CBOE.
"""

import pandas as pd
import requests
import yfinance as yf
from functools import lru_cache
from datetime import datetime
from typing import Dict, List, Optional


def fetch_cboe_equities() -> pd.DataFrame:
    """
    Downloads the Cboe Weeklys CSV and parses out only the Equity section.
    """
    url = "https://www.cboe.com/available_weeklys/get_csv_download/"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        content = response.text
        
        # Cboe CSV is structured with header strings marking sections.
        # We look for the Equity section specifically.
        equity_lines = []
        found_equity = False
        
        for line in content.splitlines():
            line = line.strip()
            if "Available Weeklys - Equity" in line:
                found_equity = True
                continue
            
            # Stop if we hit the next major header or if the line is empty
            if found_equity:
                if "Available Weeklys" in line and "Equity" not in line:
                    break
                if line and "," in line:
                    # Clean the quotes and split
                    parts = [p.strip('"') for p in line.split(',')]
                    if len(parts) >= 2:
                        equity_lines.append({"Ticker": parts[0], "Name": parts[1]})
        
        return pd.DataFrame(equity_lines)
    
    except Exception as e:
        return pd.DataFrame(columns=['Ticker', 'Name', 'error'])


def fetch_prices_batch(tickers: List[str]) -> Dict[str, Optional[float]]:
    """
    Fetches the latest prices for a list of tickers using yfinance.
    Batched for efficiency.
    """
    if not tickers:
        return {}
    
    try:
        # Fetching in one large batch is significantly faster than individual calls
        data = yf.download(tickers, period="1d", interval="1m", group_by='ticker', progress=False)
        
        prices = {}
        for ticker in tickers:
            try:
                # Handle different dataframe structures returned by yfinance for single vs multiple tickers
                if len(tickers) == 1:
                    price = data['Close'].iloc[-1]
                else:
                    price = data[ticker]['Close'].iloc[-1]
                prices[ticker] = round(float(price), 2)
            except:
                prices[ticker] = None
        return prices
    except Exception as e:
        return {t: None for t in tickers}


# Cache for the weeklies list (refreshes hourly)
_weeklies_cache = {'data': None, 'timestamp': None}
_CACHE_TTL = 3600  # 1 hour


def get_weekly_equities(with_prices: bool = False) -> pd.DataFrame:
    """
    Get the list of equities with weekly options, optionally with current prices.
    
    Args:
        with_prices: If True, fetches current prices for all tickers (can be slow)
    
    Returns:
        DataFrame with Ticker, Name, and optionally Price columns
    """
    global _weeklies_cache
    
    # Check cache
    now = datetime.now().timestamp()
    if (_weeklies_cache['data'] is not None and 
        _weeklies_cache['timestamp'] is not None and
        now - _weeklies_cache['timestamp'] < _CACHE_TTL):
        df = _weeklies_cache['data'].copy()
    else:
        # Fetch fresh data
        df = fetch_cboe_equities()
        _weeklies_cache['data'] = df.copy()
        _weeklies_cache['timestamp'] = now
    
    if df.empty:
        return df
    
    if with_prices:
        tickers = df["Ticker"].tolist()
        price_map = fetch_prices_batch(tickers)
        df["Price"] = df["Ticker"].map(price_map)
    
    return df


def search_weeklies(query: str, df: pd.DataFrame = None) -> pd.DataFrame:
    """
    Search the weeklies list by ticker or name.
    """
    if df is None:
        df = get_weekly_equities()
    
    if df.empty or not query:
        return df
    
    query = query.upper()
    return df[
        (df["Ticker"].str.upper().str.contains(query)) | 
        (df["Name"].str.upper().str.contains(query))
    ]


if __name__ == '__main__':
    print("Fetching CBOE equity weeklies...")
    df = get_weekly_equities(with_prices=False)
    print(f"\nFound {len(df)} equities with weekly options:")
    print(df.head(20).to_string())
    
    print("\n\nFetching prices for first 10...")
    sample = df.head(10)['Ticker'].tolist()
    prices = fetch_prices_batch(sample)
    for ticker, price in prices.items():
        print(f"  {ticker}: ${price:.2f}" if price else f"  {ticker}: N/A")

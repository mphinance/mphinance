from nicegui import ui, app
import scanner_logic
import strategies
import asbury_metrics
import fundamental_metrics
import options_flow
import cboe_weeklies
import stock_analyzer
import plotly.graph_objects as go
import pandas as pd
from datetime import datetime, timedelta
import asyncio

# Optional premium module - gracefully handle if gitignored
try:
    import wheel_screener
    WHEEL_SCREENER_AVAILABLE = True
except ImportError:
    wheel_screener = None
    WHEEL_SCREENER_AVAILABLE = False

# --- STYLING (Dark Navy Theme matching screenshot) ---
ui.add_head_html('''
<style>
    body { 
        background-color: #0a0e17; 
        color: #e5e5e5; 
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }
    .nicegui-content { padding: 0; }
    .q-drawer { background-color: #0d1320 !important; border-right: 1px solid #1a2332; }
    
    /* Metric Cards */
    .metric-card { 
        background: linear-gradient(145deg, #111827, #0d1320);
        padding: 1.25rem; 
        border-radius: 12px; 
        border: 1px solid #1f2937;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    .metric-label { 
        font-size: 0.75rem; 
        color: #6b7280; 
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
    }
    .metric-value { 
        font-size: 2rem; 
        font-weight: 700; 
        color: #00d4aa; 
    }
    
    /* Status Indicators */
    .st-bullish { color: #10b981; }
    .st-bearish { color: #ef4444; }
    .st-neutral { color: #6b7280; }
    
    /* Table Styling */
    .q-table { background-color: #0d1320 !important; }
    .q-table thead tr th { 
        background-color: #111827 !important; 
        color: #9ca3af !important;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.7rem;
        letter-spacing: 0.05em;
    }
    .q-table tbody tr { background-color: #0d1320 !important; }
    .q-table tbody tr:hover { background-color: #1a2332 !important; }
    .q-table tbody tr td { color: #e5e5e5 !important; border-color: #1f2937 !important; }
    
    /* Sidebar Styling */
    .sidebar-title { 
        font-size: 1.25rem; 
        font-weight: bold; 
        color: #fff;
        text-align: center;
        padding: 1rem 0;
    }
    .sidebar-section { 
        background-color: #111827;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
    }
    .section-label {
        font-size: 0.8rem;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 0.5rem;
    }
    
    /* Card styling */
    .nicegui-card {
        background-color: #111827 !important;
        border: 1px solid #1f2937;
    }
    
    /* Button styling */
    .q-btn--outline { border-color: #00d4aa !important; color: #00d4aa !important; }
</style>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
''')

# --- STATE ---
class AppState:
    def __init__(self):
        self.mode = 'Market Health'
        self.scanner_results = pd.DataFrame()
        self.target_ticker = ''
        self.selected_strategy = 'Momentum with Pullback'
        self.strategy_params = {}

state = AppState()

# --- HELPER FUNCTIONS ---

def format_market_cap(value):
    """Format market cap with B/M suffix."""
    if pd.isna(value) or value == 0:
        return '-'
    if value >= 1_000_000_000:
        return f"${value / 1_000_000_000:.1f}B"
    elif value >= 1_000_000:
        return f"${value / 1_000_000:.0f}M"
    else:
        return f"${value:,.0f}"

def format_number(value, decimals=2, prefix='', suffix=''):
    """Format a number with optional prefix/suffix."""
    if pd.isna(value):
        return '-'
    return f"{prefix}{value:.{decimals}f}{suffix}"

def format_premium(value):
    """Format premium values for display."""
    if value is None:
        return '-'
    if abs(value) >= 1e9:
        return f"${value/1e9:.1f}B"
    elif abs(value) >= 1e6:
        return f"${value/1e6:.1f}M"
    elif abs(value) >= 1e3:
        return f"${value/1e3:.0f}K"
    else:
        return f"${value:,.0f}"

# --- UI LOGIC ---

def update_ui():
    content_container.clear()
    with content_container:
        if state.mode == 'Market Health':
            render_market_health_view()
        elif state.mode == 'Market Screens':
            render_scanner_view()
        elif state.mode == 'Weekly Options':
            render_weeklies_view()
        elif state.mode == 'Wheel Screener':
            render_wheel_view()
        elif state.mode == 'Single Ticker Audit':
            render_audit_view()

def render_market_health_view():
    """Render the Asbury 6 Market Health Dashboard."""
    ui.label('📊 Market Health Gauge (A6)').classes('text-2xl font-bold mb-2 text-white')
    ui.label('Quantitative daily gauge of US equity market internal strength. Signal: Buy SPY when 4+ components are green (Positive) • Move to cash when 4+ are red (Negative)').classes('text-xs text-gray-400 mb-6')
    
    # Fetch market health data
    with ui.row().classes('w-full justify-center mb-6'):
        ui.spinner('dots', size='lg')
    
    async def load_market_health():
        content_container.clear()
        with content_container:
            ui.label('📊 Market Health Gauge (A6)').classes('text-2xl font-bold mb-2 text-white')
            ui.label('Quantitative daily gauge of US equity market internal strength').classes('text-xs text-gray-400 mb-4')
            
            result = await asyncio.to_thread(asbury_metrics.get_asbury_6_signals)
            
            if result.get('error'):
                ui.label(f"Error loading market data: {result['error']}").classes('text-red-400')
                return
            
            signal = result['signal']
            positive_count = result['positive_count']
            
            # === TOP ROW: Gauge + Signal + VIX Term Structure ===
            with ui.row().classes('w-full gap-4 mb-6'):
                
                # Gauge visualization using Plotly
                with ui.column().classes('metric-card flex-none w-48'):
                    import plotly.graph_objects as go
                    
                    # Create gauge chart
                    gauge_fig = go.Figure(go.Indicator(
                        mode="gauge+number",
                        value=positive_count,
                        domain={'x': [0, 1], 'y': [0, 1]},
                        gauge={
                            'axis': {'range': [0, 6], 'tickwidth': 1, 'tickcolor': "#1f2937"},
                            'bar': {'color': "#00d4aa" if positive_count >= 4 else "#ef4444" if positive_count <= 2 else "#f59e0b"},
                            'bgcolor': "#1f2937",
                            'borderwidth': 2,
                            'bordercolor': "#374151",
                            'steps': [
                                {'range': [0, 2], 'color': 'rgba(239, 68, 68, 0.3)'},
                                {'range': [2, 4], 'color': 'rgba(245, 158, 11, 0.3)'},
                                {'range': [4, 6], 'color': 'rgba(16, 185, 129, 0.3)'}
                            ],
                        },
                        number={'suffix': '/6', 'font': {'color': '#e5e5e5', 'size': 24}}
                    ))
                    gauge_fig.update_layout(
                        paper_bgcolor='rgba(0,0,0,0)',
                        plot_bgcolor='rgba(0,0,0,0)',
                        font={'color': '#e5e5e5'},
                        height=150,
                        margin=dict(l=20, r=20, t=30, b=10)
                    )
                    ui.plotly(gauge_fig).classes('w-full')
                
                # Signal Card
                signal_colors = {'BUY': 'bg-green-900 border-green-500', 'CASH': 'bg-red-900 border-red-500', 'NEUTRAL': 'bg-yellow-900 border-yellow-500'}
                signal_text_colors = {'BUY': 'text-green-400', 'CASH': 'text-red-400', 'NEUTRAL': 'text-yellow-400'}
                
                with ui.column().classes(f'metric-card flex-1 border-2 {signal_colors.get(signal, "")}'):
                    with ui.row().classes('items-center gap-2'):
                        ui.label('●').classes(f'text-2xl {signal_text_colors.get(signal, "")}')
                        ui.label(f'{signal} SIGNAL').classes(f'text-2xl font-bold {signal_text_colors.get(signal, "")}')
                    ui.label(f'{positive_count}/6 Positive').classes('text-gray-400 mt-1')
                    recommendation = 'Increase Equity' if signal == 'BUY' else 'Reduce Exposure' if signal == 'CASH' else 'Hold Current'
                    ui.label(f'Recommend: {recommendation}').classes('text-sm text-gray-300')
                    ui.label(f"Updated: {result['timestamp']}").classes('text-xs text-gray-500 mt-2')
                
                # VIX Term Structure
                with ui.column().classes('metric-card flex-1 bg-teal-900 border border-teal-600'):
                    ui.label('VIX Term Structure').classes('text-lg font-bold text-white mb-2')
                    
                    # Get VIX data
                    try:
                        import yfinance as yf
                        vix = yf.Ticker('^VIX')
                        vix_spot = vix.info.get('regularMarketPrice', 0)
                        vix3m = yf.Ticker('^VIX3M')
                        vix_3m = vix3m.info.get('regularMarketPrice', 0)
                        spread = vix_3m - vix_spot if vix_3m and vix_spot else 0
                        structure = 'Contango (Bullish)' if spread > 0 else 'Backwardation (Bearish)'
                        structure_color = 'text-green-400' if spread > 0 else 'text-red-400'
                    except:
                        vix_spot, vix_3m, spread = 0, 0, 0
                        structure = 'N/A'
                        structure_color = 'text-gray-400'
                    
                    with ui.row().classes('w-full gap-4'):
                        with ui.column().classes('flex-1 text-center'):
                            ui.label('Spot').classes('text-xs text-gray-400')
                            ui.label(f'{vix_spot:.2f}' if vix_spot else '-').classes('text-xl font-bold text-white')
                        with ui.column().classes('flex-1 text-center'):
                            ui.label('3M Fwd').classes('text-xs text-gray-400')
                            ui.label(f'{vix_3m:.2f}' if vix_3m else '-').classes('text-xl font-bold text-white')
                        with ui.column().classes('flex-1 text-center'):
                            ui.label('Spread').classes('text-xs text-gray-400')
                            ui.label(f'{spread:+.2f}' if spread else '-').classes('text-xl font-bold text-white')
                    ui.label(structure).classes(f'text-sm font-bold mt-2 {structure_color}')
            
            # === MARKET HEALTH METRICS GRID ===
            ui.label('📈 Market Health Metrics').classes('text-xl font-bold text-white mb-4')
            
            # Two rows of 3 metrics each
            metrics = result['metrics']
            with ui.row().classes('w-full gap-2 mb-2'):
                for metric in metrics[:3]:
                    is_positive = metric['status'] == 'Positive'
                    bg_color = 'bg-green-900' if is_positive else 'bg-red-900'
                    status_text = 'Positive' if is_positive else 'Negative'
                    
                    with ui.column().classes(f'flex-1 p-3 rounded {bg_color}'):
                        with ui.row().classes('w-full justify-between items-center'):
                            ui.label(f"● {metric['name']}").classes('text-white font-bold')
                            ui.label(status_text).classes('text-xs text-gray-300')
                        ui.label(metric['value']).classes('text-xs text-cyan-300 mt-1')
            
            with ui.row().classes('w-full gap-2'):
                for metric in metrics[3:]:
                    is_positive = metric['status'] == 'Positive'
                    bg_color = 'bg-green-900' if is_positive else 'bg-red-900'
                    status_text = 'Positive' if is_positive else 'Negative'
                    
                    with ui.column().classes(f'flex-1 p-3 rounded {bg_color}'):
                        with ui.row().classes('w-full justify-between items-center'):
                            ui.label(f"● {metric['name']}").classes('text-white font-bold')
                            ui.label(status_text).classes('text-xs text-gray-300')
                        ui.label(metric['value']).classes('text-xs text-cyan-300 mt-1')
            
            # Refresh button
            ui.separator().classes('bg-gray-700 my-6')
            
            async def refresh_data():
                ui.notify('Refreshing market data...', type='info')
                await load_market_health()
            
            ui.button('🔄 Refresh Data', on_click=refresh_data).props('outline color=cyan')
    
    # Use ui.timer for deferred async execution (works without running loop)
    ui.timer(0.1, load_market_health, once=True)

def render_scanner_view():
    strategy = strategies.get_strategy_by_display_name(state.selected_strategy)
    
    ui.label('Live Market Scanner').classes('text-2xl font-bold mb-2 text-white')
    ui.label(f'Strategy: {strategy.name}').classes('text-sm text-gray-400 mb-4')
    
    with ui.row().classes('w-full gap-4'):
        if not state.scanner_results.empty:
            with ui.row().classes('w-full items-center justify-between'):
                ui.label(f"Showing {len(state.scanner_results)} matches for {strategy.name}").classes('text-green-400')
                
                def download_txt():
                    txt_data = scanner_logic.convert_df_to_txt(state.scanner_results)
                    filename = f"screen_{state.selected_strategy.lower().replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M')}.txt"
                    ui.download(txt_data, filename)

                ui.button('📥 Export as TXT', on_click=download_txt).props('outline color=green')

            # Build columns based on strategy - add Weekly indicator first
            columns = [
                {'name': 'weekly', 'label': '📅', 'field': 'weekly', 'sortable': True, 'align': 'center'},
                {'name': 'name', 'label': 'Ticker', 'field': 'name', 'sortable': True, 'align': 'left'},
                {'name': 'description', 'label': 'Company', 'field': 'description', 'sortable': True, 'align': 'left'},
                {'name': 'close', 'label': 'Price', 'field': 'close', 'sortable': True, 'align': 'right'},
                {'name': 'change', 'label': 'Chg %', 'field': 'change', 'sortable': True, 'align': 'right'},
                {'name': 'market_cap', 'label': 'Mkt Cap', 'field': 'market_cap', 'sortable': True, 'align': 'right'},
            ]
            
            # Add columns for Momentum strategy
            if state.selected_strategy == 'Momentum with Pullback':
                columns.extend([
                    {'name': 'EMA8', 'label': 'EMA8', 'field': 'EMA8', 'sortable': True, 'align': 'right'},
                    {'name': 'EMA21', 'label': 'EMA21', 'field': 'EMA21', 'sortable': True, 'align': 'right'},
                    {'name': 'EMA34', 'label': 'EMA34', 'field': 'EMA34', 'sortable': True, 'align': 'right'},
                    {'name': 'EMA55', 'label': 'EMA55', 'field': 'EMA55', 'sortable': True, 'align': 'right'},
                    {'name': 'EMA89', 'label': 'EMA89', 'field': 'EMA89', 'sortable': True, 'align': 'right'},
                    {'name': 'ADX', 'label': 'ADX', 'field': 'ADX', 'sortable': True, 'align': 'right'},
                    {'name': 'ATR', 'label': 'ATR', 'field': 'ATR', 'sortable': True, 'align': 'right'},
                    {'name': 'ATR_1W', 'label': 'ATR 1W', 'field': 'ATR_1W', 'sortable': True, 'align': 'right'},
                    {'name': 'SMA50', 'label': 'SMA50', 'field': 'SMA50', 'sortable': True, 'align': 'right'},
                    {'name': 'Stoch_K', 'label': 'Stoch K', 'field': 'Stoch_K', 'sortable': True, 'align': 'right'},
                ])
            else:  # Small Cap Multibaggers
                columns.extend([
                    {'name': 'gross_margin', 'label': 'Gross Margin', 'field': 'gross_margin', 'sortable': True, 'align': 'right'},
                    {'name': 'revenue_growth', 'label': 'Rev Growth 3Y', 'field': 'revenue_growth', 'sortable': True, 'align': 'right'},
                    {'name': 'fcf', 'label': 'FCF', 'field': 'fcf', 'sortable': True, 'align': 'right'},
                ])
            
            # Get weeklies list for indicator
            weeklies_df = cboe_weeklies.get_weekly_equities(with_prices=False)
            weekly_tickers = set(weeklies_df['Ticker'].tolist()) if not weeklies_df.empty else set()
            
            # Format the data for display
            rows = []
            for _, row in state.scanner_results.iterrows():
                ticker = row['name']
                has_weekly = ticker in weekly_tickers
                row_data = {
                    'weekly': '📅' if has_weekly else '',
                    'name': ticker,
                    'description': str(row.get('description', ''))[:30],
                    'close': f"${row['close']:.2f}",
                    'change': f"{row['change']:+.2f}%",
                    'market_cap': format_market_cap(row.get('market_cap_basic', 0)),
                }
                
                if state.selected_strategy == 'Momentum':
                    row_data.update({
                        'EMA8': f"${row.get('EMA8', 0):.2f}",
                        'EMA21': f"${row.get('EMA21', 0):.2f}",
                        'EMA34': f"${row.get('EMA34', 0):.2f}",
                        'EMA55': f"${row.get('EMA55', 0):.2f}",
                        'EMA89': f"${row.get('EMA89', 0):.2f}",
                        'ADX': f"{row.get('ADX', 0):.1f}",
                        'ATR': f"${row.get('ATR', 0):.2f}",
                        'ATR_1W': f"${row.get('ATR_1W', 0):.2f}",
                        'SMA50': f"${row.get('SMA50', 0):.2f}",
                        'Stoch_K': f"{row.get('Stoch_K', 0):.1f}",
                    })
                else:
                    row_data.update({
                        'gross_margin': f"{row.get('gross_margin', 0):.1f}%",
                        'revenue_growth': f"{row.get('revenue_growth_3y', 0):.1f}%",
                        'fcf': format_market_cap(row.get('free_cash_flow', 0)),
                    })
                
                rows.append(row_data)
            
            table = ui.table(columns=columns, rows=rows, row_key='name', pagination=20).classes('w-full')
            table.props('dark flat bordered dense')
            
            # Add TradingView link for ticker column
            table.add_slot('body-cell-name', '''
                <q-td :props="props">
                    <a :href="'https://www.tradingview.com/symbols/' + props.value" target="_blank" class="text-cyan-400 hover:underline">
                        {{ props.value }}
                    </a>
                </q-td>
            ''')
            
            def on_row_click(e):
                ticker = e.args[1]['name']
                state.target_ticker = ticker
                state.mode = 'Single Ticker Audit'
                mode_select.value = 'Single Ticker Audit'
                update_ui()
            
            table.on('rowClick', on_row_click)
            
            # Copy/Paste Text Box
            ui.separator().classes('my-4')
            ui.label('📋 Copy Tickers').classes('text-lg font-bold text-white mb-2')
            ticker_list = '\n'.join(state.scanner_results['name'].tolist())
            ui.textarea(value=ticker_list).props('dark outlined readonly').classes('w-full').style('height: 150px; font-family: monospace;')
            
        else:
            with ui.column().classes('w-full items-center justify-center py-16'):
                ui.label('📊').classes('text-6xl mb-4')
                ui.label('No results yet').classes('text-xl text-gray-400')
                ui.label('Select a strategy and click "Run Screen" to get started').classes('text-sm text-gray-500')

def render_weeklies_view():
    """Simple browsable list of all equities with weekly options with filtering."""
    ui.label('📅 Weekly Options').classes('text-2xl font-bold mb-2 text-white')
    ui.label('All equities with weekly options from CBOE').classes('text-sm text-gray-400 mb-4')
    
    # Filter state (stored on state object for persistence)
    if not hasattr(state, 'weeklies_filter'):
        state.weeklies_filter = {'text': '', 'min_price': 0, 'max_price': 10000}
    if not hasattr(state, 'weeklies_data'):
        state.weeklies_data = None
    
    weeklies_container = ui.column().classes('w-full')
    
    def render_table(filter_text='', min_price=0, max_price=10000):
        """Render the table with filters applied."""
        if state.weeklies_data is None:
            return
        
        df = state.weeklies_data.copy()
        
        # Apply text filter
        if filter_text:
            filter_upper = filter_text.upper()
            df = df[
                df['Ticker'].str.upper().str.contains(filter_upper, na=False) |
                df['Name'].str.upper().str.contains(filter_upper, na=False)
            ]
        
        # Apply price filter
        df = df[(df['Price'].fillna(0) >= min_price) & (df['Price'].fillna(0) <= max_price)]
        
        # Sort by price descending
        df = df.sort_values('Price', ascending=False, na_position='last')
        
        columns = [
            {'name': 'Ticker', 'label': 'Ticker', 'field': 'Ticker', 'sortable': True},
            {'name': 'Name', 'label': 'Company', 'field': 'Name', 'sortable': True},
            {'name': 'price_raw', 'label': 'Price', 'field': 'price_raw', 'sortable': True},
        ]
        
        rows = []
        for _, row in df.iterrows():
            price = row.get('Price')
            rows.append({
                'Ticker': row['Ticker'],
                'Name': row['Name'],
                'price_raw': price if price else 0,
                'price_display': f"${price:.2f}" if price else '-',
            })
        
        weeklies_container.clear()
        with weeklies_container:
            ui.label(f'✅ Showing {len(rows)} equities').classes('text-green-400 mb-2')
            table = ui.table(
                columns=columns, 
                rows=rows, 
                row_key='Ticker', 
                pagination=50
            ).classes('w-full')
            table.props('dark flat bordered dense')
            
            # Custom slot for ticker with TradingView link
            table.add_slot('body-cell-Ticker', '''
                <q-td :props="props">
                    <a :href="'https://www.tradingview.com/symbols/' + props.value" target="_blank" class="text-cyan-400 hover:underline">
                        {{ props.value }}
                    </a>
                </q-td>
            ''')
            
            # Custom slot for price display
            table.add_slot('body-cell-price_raw', '''
                <q-td :props="props">
                    ${{ props.value.toFixed(2) }}
                </q-td>
            ''')
            
            # Copy ticker list
            ui.separator().classes('bg-gray-700 my-4')
            ui.label('📋 Copy Tickers:').classes('text-white mb-2')
            ticker_list = '\n'.join(df['Ticker'].tolist())
            ui.textarea(value=ticker_list).props('dark outlined readonly').classes('w-full').style('height: 120px; font-family: monospace;')
    
    async def load_weeklies():
        ui.notify('Loading weeklies with prices (may take a moment)...', type='info')
        state.weeklies_data = await asyncio.to_thread(cboe_weeklies.get_weekly_equities, True)
        
        if state.weeklies_data is None or state.weeklies_data.empty:
            ui.notify('Could not fetch weeklies list', type='negative')
            return
        
        ui.notify(f'Loaded {len(state.weeklies_data)} equities!', type='positive')
        render_table(state.weeklies_filter['text'], state.weeklies_filter['min_price'], state.weeklies_filter['max_price'])
    
    def apply_filter():
        render_table(state.weeklies_filter['text'], state.weeklies_filter['min_price'], state.weeklies_filter['max_price'])
    
    with ui.row().classes('gap-4 mb-4 items-end flex-wrap'):
        ui.button('📋 Load Weekly Options', on_click=load_weeklies).props('color=primary')
        
        with ui.column().classes('gap-1'):
            ui.label('Search').classes('text-xs text-gray-400')
            ui.input(placeholder='Filter by ticker or name').props('outlined dense dark').classes('w-48').bind_value(state.weeklies_filter, 'text').on('keyup.enter', apply_filter)
        
        with ui.column().classes('gap-1'):
            ui.label('Min Price').classes('text-xs text-gray-400')
            ui.number(value=0, min=0).props('outlined dense dark').classes('w-24').bind_value(state.weeklies_filter, 'min_price')
        
        with ui.column().classes('gap-1'):
            ui.label('Max Price').classes('text-xs text-gray-400')
            ui.number(value=10000, min=0).props('outlined dense dark').classes('w-24').bind_value(state.weeklies_filter, 'max_price')
        
        ui.button('🔍 Filter', on_click=apply_filter).props('color=green outline')
    
    # Show existing data if available
    if state.weeklies_data is not None and not state.weeklies_data.empty:
        render_table(state.weeklies_filter['text'], state.weeklies_filter['min_price'], state.weeklies_filter['max_price'])

def render_wheel_view():
    """Render the Wheel Screener for Cash Secured Puts."""
    # Check if wheel_screener module is available
    if not WHEEL_SCREENER_AVAILABLE:
        ui.label('🎡 Wheel Screener').classes('text-2xl font-bold mb-2 text-white')
        with ui.column().classes('w-full items-center justify-center py-16'):
            ui.label('🔒').classes('text-6xl mb-4')
            ui.label('Premium Feature').classes('text-xl text-yellow-400')
            ui.label('Wheel Screener is a premium feature. Contact for access.').classes('text-sm text-gray-500')
        return
    
    ui.label('🎡 Wheel Screener').classes('text-2xl font-bold mb-2 text-white')
    ui.label('Cash-secured put opportunities for small accounts • Finds high-yield OTM puts').classes('text-sm text-gray-400 mb-4')
    
    # Initialize wheel config in state
    if not hasattr(state, 'wheel_config'):
        state.wheel_config = wheel_screener.get_default_config()
    if not hasattr(state, 'wheel_results'):
        state.wheel_results = pd.DataFrame()
    
    results_container = ui.column().classes('w-full')
    progress_container = ui.column().classes('w-full mb-4')
    
    async def run_wheel_scan():
        config = state.wheel_config.copy()
        
        progress_container.clear()
        with progress_container:
            progress_label = ui.label('Starting scan...').classes('text-gray-400')
            progress_bar = ui.linear_progress(value=0).classes('w-full')
        
        def progress_callback(current, total):
            progress_bar.value = current / total
            progress_label.text = f'Analyzing {current}/{total} candidates...'
        
        ui.notify('Running wheel scan...', type='info')
        
        try:
            results = await asyncio.to_thread(wheel_screener.run_wheel_scan, config, progress_callback)
            state.wheel_results = results
            
            if results.empty:
                ui.notify('No opportunities found. Try widening filters.', type='warning')
            else:
                ui.notify(f'Found {len(results)} opportunities!', type='positive')
            
            update_ui()
        except Exception as e:
            ui.notify(f'Error: {str(e)}', type='negative')
            print(f"Wheel scan error: {e}")
    
    # === CONTROLS ROW ===
    with ui.row().classes('w-full gap-6 mb-6 flex-wrap items-end'):
        
        # DTE Range
        with ui.column().classes('gap-1'):
            ui.label('DTE Range').classes('text-sm text-gray-400')
            with ui.row().classes('gap-2'):
                ui.number(label='Min', value=state.wheel_config['dte_range'][0], min=1, max=120).props('outlined dense dark').classes('w-20').on('update:model-value', lambda e: state.wheel_config.update({'dte_range': (int(e.args), state.wheel_config['dte_range'][1])}))
                ui.number(label='Max', value=state.wheel_config['dte_range'][1], min=1, max=120).props('outlined dense dark').classes('w-20').on('update:model-value', lambda e: state.wheel_config.update({'dte_range': (state.wheel_config['dte_range'][0], int(e.args))}))
        
        # Capital
        with ui.column().classes('gap-1'):
            ui.label('Max Capital ($)').classes('text-sm text-gray-400')
            ui.number(value=state.wheel_config['max_capital'], min=100, max=50000, step=100).props('outlined dense dark').classes('w-28').bind_value(state.wheel_config, 'max_capital')
        
        # Price Range
        with ui.column().classes('gap-1'):
            ui.label('Stock Price ($)').classes('text-sm text-gray-400')
            with ui.row().classes('gap-2'):
                ui.number(label='Min', value=state.wheel_config['min_price'], min=0.5, max=500).props('outlined dense dark').classes('w-20').bind_value(state.wheel_config, 'min_price')
                ui.number(label='Max', value=state.wheel_config['max_price'], min=1, max=1000).props('outlined dense dark').classes('w-20').bind_value(state.wheel_config, 'max_price')
        
        # Min Weekly ROC
        with ui.column().classes('gap-1'):
            ui.label('Min Weekly ROC %').classes('text-sm text-gray-400')
            ui.number(value=state.wheel_config['min_roc_weekly'], min=0.1, max=10, step=0.1).props('outlined dense dark').classes('w-24').bind_value(state.wheel_config, 'min_roc_weekly')
        
        ui.button('🚀 Run Wheel Scan', on_click=run_wheel_scan).props('color=primary')
    
    # === ADVANCED FILTERS (collapsible) ===
    with ui.expansion('Advanced Filters', icon='tune').classes('w-full mb-4'):
        with ui.row().classes('gap-6 flex-wrap'):
            with ui.column().classes('gap-1'):
                ui.label('Max ADX').classes('text-xs text-gray-400')
                ui.number(value=state.wheel_config['max_adx'], min=20, max=100).props('outlined dense dark').classes('w-24').bind_value(state.wheel_config, 'max_adx')
            
            with ui.column().classes('gap-1'):
                ui.label('RSI Range').classes('text-xs text-gray-400')
                with ui.row().classes('gap-2'):
                    ui.number(label='Min', value=state.wheel_config['min_rsi'], min=0, max=50).props('outlined dense dark').classes('w-20').bind_value(state.wheel_config, 'min_rsi')
                    ui.number(label='Max', value=state.wheel_config['max_rsi'], min=50, max=100).props('outlined dense dark').classes('w-20').bind_value(state.wheel_config, 'max_rsi')
            
            with ui.column().classes('gap-1'):
                ui.label('Min Monthly Vol %').classes('text-xs text-gray-400')
                ui.number(value=state.wheel_config['min_vol_m'], min=0, max=10, step=0.5).props('outlined dense dark').classes('w-24').bind_value(state.wheel_config, 'min_vol_m')
            
            with ui.column().classes('gap-1'):
                ui.label('Max Results').classes('text-xs text-gray-400')
                ui.number(value=state.wheel_config['max_results'], min=5, max=50).props('outlined dense dark').classes('w-20').bind_value(state.wheel_config, 'max_results')
    
    # === RESULTS TABLE ===
    if not state.wheel_results.empty:
        ui.label(f'✅ Found {len(state.wheel_results)} CSP opportunities').classes('text-green-400 text-lg mb-4')
        
        columns = [
            {'name': 'symbol', 'label': 'Symbol', 'field': 'symbol', 'sortable': True},
            {'name': 'current_price', 'label': 'Price', 'field': 'current_price', 'sortable': True},
            {'name': 'strike', 'label': 'Strike', 'field': 'strike', 'sortable': True},
            {'name': 'capital_required', 'label': 'Capital', 'field': 'capital_required', 'sortable': True},
            {'name': 'dte', 'label': 'DTE', 'field': 'dte', 'sortable': True},
            {'name': 'roc_weekly', 'label': 'Weekly ROC', 'field': 'roc_weekly', 'sortable': True},
            {'name': 'roc_period', 'label': 'Total ROC', 'field': 'roc_period', 'sortable': True},
            {'name': 'iv', 'label': 'IV', 'field': 'iv', 'sortable': True},
            {'name': 'div_yield', 'label': 'Div Yld', 'field': 'div_yield', 'sortable': True},
            {'name': 'score', 'label': 'Score', 'field': 'score', 'sortable': True},
            {'name': 'expiration', 'label': 'Expiration', 'field': 'expiration', 'sortable': True},
        ]
        
        rows = []
        for _, row in state.wheel_results.iterrows():
            rows.append({
                'symbol': row['symbol'],
                'current_price': f"${row['current_price']:.2f}",
                'strike': f"${row['strike']:.2f}",
                'capital_required': f"${row['capital_required']:.0f}",
                'dte': f"{row['dte']:.0f}",
                'roc_weekly': f"{row['roc_weekly']:.2f}%",
                'roc_period': f"{row['roc_period']:.2f}%",
                'iv': f"{row['iv']:.1f}%",
                'div_yield': f"{row['div_yield']:.2f}%",
                'score': f"{row['score']:.1f}",
                'expiration': row['expiration'],
            })
        
        table = ui.table(columns=columns, rows=rows, row_key='symbol', pagination=20).classes('w-full')
        table.props('dark flat bordered dense')
        
        table.add_slot('body-cell-symbol', '''
            <q-td :props="props">
                <a :href="'https://www.tradingview.com/symbols/' + props.value" target="_blank" class="text-cyan-400 hover:underline">
                    {{ props.value }}
                </a>
            </q-td>
        ''')
        
        # Export
        ui.separator().classes('bg-gray-700 my-4')
        
        def download_results():
            summary = f"Wheel Scan: {state.wheel_config['dte_range'][0]}-{state.wheel_config['dte_range'][1]} DTE | Min Weekly ROC: {state.wheel_config['min_roc_weekly']}%\n\n"
            for _, row in state.wheel_results.iterrows():
                summary += f"{row['symbol']}: {row['roc_weekly']:.2f}% Weekly ({row['roc_period']:.2f}% Total) | Strike ${row['strike']:.2f} | DTE: {row['dte']:.0f}\n"
            ui.download(summary.encode(), f"wheel_scan_{datetime.now().strftime('%Y%m%d_%H%M')}.txt")
        
        with ui.row().classes('gap-4'):
            ui.button('📥 Download Results', on_click=download_results).props('outline color=green')
            
            # Copy symbols
            ticker_list = '\n'.join(state.wheel_results['symbol'].tolist())
            ui.textarea(value=ticker_list, label='Copy Tickers').props('dark outlined readonly').classes('w-48').style('height: 80px; font-family: monospace;')
    
    else:
        with ui.column().classes('w-full items-center justify-center py-12'):
            ui.label('🎡').classes('text-6xl mb-4')
            ui.label('Run a Wheel Scan to find CSP opportunities').classes('text-xl text-gray-400')
            ui.label('Set your DTE range, max capital, and price filters above').classes('text-sm text-gray-500')

def render_audit_view():
    ui.label('Single Ticker Audit').classes('text-2xl font-bold mb-4 text-white')
    
    with ui.row().classes('items-center gap-4 mb-4'):
        ticker_input = ui.input('Ticker').props('outlined dense dark').bind_value(state, 'target_ticker')
        ui.button('Analyze', on_click=lambda: run_audit(state.target_ticker)).props('color=primary')
    
    if state.target_ticker:
        audit_results_container = ui.column().classes('w-full')
        run_audit(state.target_ticker, audit_results_container)

def run_audit(ticker, container=None):
    if container is None:
        update_ui()
        return

    container.clear()
    with container:
        if not ticker:
            return

        ui.notify(f'Analyzing {ticker}...', type='info')
        data = scanner_logic.get_live_data(ticker)
        
        if data is None:
            ui.label("Ticker not found or insufficient data (200+ days required).").classes('text-red-500 font-bold')
            return

        last = data.iloc[-1]
        price = float(last['Close'])
        sma200 = float(last['SMA200'])
        ema21 = float(last['EMA21'])
        atr = float(last['ATR'])
        atr55 = float(last['ATR55'])
        stoch = float(last['Stoch'])
        
        # Calculate squeeze ratio (lower = more compressed)
        squeeze_ratio = atr / atr55 if atr55 > 0 else 1.0
        is_squeezed = squeeze_ratio < 0.85  # ATR14 less than 85% of ATR55 indicates squeeze

        # Metrics
        with ui.row().classes('w-full gap-4 mb-6'):
            with ui.column().classes('metric-card flex-1'):
                ui.label('Current Price').classes('metric-label')
                ui.label(f"${price:.2f}").classes('metric-value')
            with ui.column().classes('metric-card flex-1'):
                ui.label('200 SMA').classes('metric-label')
                ui.label(f"${sma200:.2f}").classes('metric-value')
            with ui.column().classes('metric-card flex-1'):
                ui.label('ATR (14)').classes('metric-label')
                ui.label(f"${atr:.2f}").classes('metric-value')
            with ui.column().classes('metric-card flex-1'):
                ui.label('ATR (55)').classes('metric-label')
                ui.label(f"${atr55:.2f}").classes('metric-value')
            with ui.column().classes('metric-card flex-1'):
                ui.label('EMA 21').classes('metric-label')
                ui.label(f"${ema21:.2f}").classes('metric-value')
            with ui.column().classes('metric-card flex-1'):
                ui.label('Stoch (8,3,3)').classes('metric-label')
                ui.label(f"{stoch:.1f}").classes('metric-value')
        
        # Squeeze indicator row
        with ui.row().classes('w-full gap-4 mb-4'):
            squeeze_bg = 'bg-green-900' if is_squeezed else 'bg-gray-800'
            squeeze_text = '🔋 SQUEEZED' if is_squeezed else 'Normal Volatility'
            with ui.column().classes(f'metric-card {squeeze_bg}'):
                ui.label('Volatility Squeeze').classes('metric-label')
                ui.label(squeeze_text).classes('text-lg font-bold text-white')
                ui.label(f"ATR14/ATR55 Ratio: {squeeze_ratio:.2f}").classes('text-sm text-gray-400')

        ui.separator().classes('bg-gray-700 my-4')

        with ui.row().classes('w-full gap-4'):
            # Chart - Zoomed to last 30 days by default
            with ui.card().classes('w-2/3 bg-gray-900'):
                # Get last 30 days of data
                recent_data = data.tail(30)
                
                fig = go.Figure(data=[go.Candlestick(
                    x=recent_data.index, 
                    open=recent_data['Open'], 
                    high=recent_data['High'], 
                    low=recent_data['Low'], 
                    close=recent_data['Close'], 
                    name="Price"
                )])
                colors = ['#00d4aa', '#00b4d8', '#3a86ff', '#8338ec', '#ff006e']
                for i, p in enumerate([8, 21, 34, 55, 89]):
                    fig.add_trace(go.Scatter(
                        x=recent_data.index, 
                        y=recent_data[f'EMA{p}'], 
                        name=f'EMA {p}', 
                        line=dict(color=colors[i], width=1.5)
                    ))
                fig.add_trace(go.Scatter(
                    x=recent_data.index, 
                    y=recent_data['SMA200'], 
                    name='200 SMA', 
                    line=dict(color='white', width=2, dash='dash')
                ))
                fig.update_layout(
                    template="plotly_dark", 
                    height=500, 
                    margin=dict(l=0, r=0, t=30, b=0), 
                    xaxis_rangeslider_visible=False, 
                    paper_bgcolor='rgba(0,0,0,0)', 
                    plot_bgcolor='rgba(13,19,32,1)',
                    title=dict(text=f'{ticker} - Last 30 Days', font=dict(size=14, color='#9ca3af')),
                    legend=dict(
                        orientation="h",
                        yanchor="bottom",
                        y=1.02,
                        xanchor="right",
                        x=1,
                        font=dict(size=10)
                    )
                )
                ui.plotly(fig).classes('w-full h-full')

            # Analysis
            with ui.card().classes('w-1/3 bg-gray-900 p-4'):
                ui.label("⚙️ Mechanics Check").classes('text-xl font-bold mb-4 text-white')
                
                if price > sma200:
                    ui.label("✅ SAILING WITH THE WIND").classes('text-green-400 font-bold')
                else:
                    ui.label("❌ STAGNANT WATER: Below 200 SMA").classes('text-red-400 font-bold')

                ui.label("📊 EMA Stack Values").classes('text-lg font-bold mt-4 mb-2 text-white')
                e8, e21, e34, e55, e89 = (float(last['EMA8']), float(last['EMA21']), 
                                          float(last['EMA34']), float(last['EMA55']), float(last['EMA89']))
                
                with ui.column().classes('gap-1'):
                    ui.label(f"EMA 8: ${e8:.2f}")
                    ui.label(f"EMA 21: ${e21:.2f}")
                    ui.label(f"EMA 34: ${e34:.2f}")
                    ui.label(f"EMA 55: ${e55:.2f}")
                    ui.label(f"EMA 89: ${e89:.2f}")

                is_stacked = (e8 > e21 > e34 > e55 > e89)
                if is_stacked:
                    ui.label("✅ BULLISH STACK CONFIRMED").classes('text-green-400 font-bold mt-2')
                else:
                    ui.label("⚠️ STACK DISORDERED").classes('text-yellow-400 font-bold mt-2')

                dist_to_21 = abs(price - e21)
                if dist_to_21 <= atr:
                    ui.label("🎯 IN THE BUY ZONE (Within 1 ATR)").classes('text-blue-400 font-bold mt-2')
                else:
                    ui.label("⌛ OVEREXTENDED: Wait for Pullback").classes('text-yellow-400 font-bold mt-2')

                ui.separator().classes('bg-gray-700 my-4')
                
                ui.label("📝 Tactical Execution").classes('text-xl font-bold mb-2 text-white')
                stop_loss = price - (atr * 1.5)
                tp1 = price + (atr * 1.2)
                tp2 = price + (atr * 2.5)
                
                ui.label(f"Stop Loss: ${stop_loss:.2f}").classes('text-red-400')
                ui.label(f"Take Profit 1: ${tp1:.2f}").classes('text-green-400')
                ui.label(f"Take Profit 2: ${tp2:.2f}").classes('text-green-400')

        # === ML PRICE PREDICTION SECTION ===
        ui.separator().classes('bg-gray-700 my-6')
        ui.label('🔮 AI Price Prediction').classes('text-xl font-bold text-white mb-4')
        
        # Calculate technical indicators and train model
        analyzer = stock_analyzer.StockAnalyzer()
        data_with_indicators = analyzer.calculate_technical_indicators(data)
        model_info = analyzer.train_prediction_model(data_with_indicators)
        
        if model_info:
            current_price = float(data['Close'].iloc[-1])
            prediction = analyzer.predict_price_range(model_info, current_price)
            
            if prediction:
                horizon = prediction['horizon']
                confidence = model_info['test_score']
                
                # Header with horizon
                ui.label(f"📆 {horizon}-Day Price Target Range").classes('text-lg text-cyan-400 mb-2')
                
                with ui.row().classes('w-full gap-4 mb-4'):
                    # Low target card
                    low_color = 'text-red-400' if prediction['low_change_pct'] < 0 else 'text-green-400'
                    with ui.column().classes('metric-card flex-1 bg-red-900/30 border border-red-800'):
                        ui.label('Low Target').classes('metric-label')
                        ui.label(f"${prediction['low']:.2f}").classes('text-2xl font-bold text-white')
                        ui.label(f"{prediction['low_change_pct']:+.2f}%").classes(f'{low_color} font-bold')
                    
                    # Expected target card (center, larger)
                    exp_color = 'bg-green-900' if prediction['expected_change_pct'] > 0 else 'bg-red-900'
                    with ui.column().classes(f'metric-card flex-1 {exp_color} border-2 border-cyan-500'):
                        ui.label('Expected').classes('metric-label')
                        ui.label(f"${prediction['expected']:.2f}").classes('text-3xl font-bold text-white')
                        change_color = 'text-green-400' if prediction['expected_change_pct'] > 0 else 'text-red-400'
                        ui.label(f"{prediction['expected_change_pct']:+.2f}%").classes(f'{change_color} font-bold text-lg')
                    
                    # High target card 
                    high_color = 'text-green-400' if prediction['high_change_pct'] > 0 else 'text-red-400'
                    with ui.column().classes('metric-card flex-1 bg-green-900/30 border border-green-800'):
                        ui.label('High Target').classes('metric-label')
                        ui.label(f"${prediction['high']:.2f}").classes('text-2xl font-bold text-white')
                        ui.label(f"{prediction['high_change_pct']:+.2f}%").classes(f'{high_color} font-bold')
                
                # Model metrics row
                with ui.row().classes('w-full gap-4 mb-4'):
                    # Confidence bar
                    conf_level = "High" if confidence > 0.8 else ("Medium" if confidence > 0.6 else "Low")
                    conf_bg = 'bg-green-900' if confidence > 0.8 else ('bg-yellow-900' if confidence > 0.6 else 'bg-red-900')
                    with ui.column().classes(f'metric-card flex-1 {conf_bg}'):
                        ui.label('Model Confidence').classes('metric-label')
                        ui.label(f"{confidence:.1%}").classes('text-xl font-bold text-white')
                        ui.label(conf_level).classes('text-gray-300 text-sm')
                    
                    # Range confidence
                    range_conf = prediction['confidence']
                    range_bg = 'bg-green-900' if range_conf > 0.7 else ('bg-yellow-900' if range_conf > 0.4 else 'bg-red-900')
                    with ui.column().classes(f'metric-card flex-1 {range_bg}'):
                        ui.label('Range Confidence').classes('metric-label')
                        ui.label(f"{range_conf:.1%}").classes('text-xl font-bold text-white')
                        ui.label('Tree agreement').classes('text-gray-300 text-sm')
                    
                    # Training info
                    with ui.column().classes('metric-card flex-1'):
                        ui.label('Model Performance').classes('metric-label')
                        ui.label(f"Train: {model_info['train_score']:.1%}").classes('text-cyan-400')
                        ui.label(f"Test: {model_info['test_score']:.1%}").classes('text-cyan-400')
                
                # Top features driving prediction
                with ui.expansion('📊 Top Prediction Factors', icon='analytics').classes('w-full'):
                    with ui.row().classes('gap-2 flex-wrap'):
                        for feature, importance in model_info['feature_importance'].items():
                            # Clean up feature name for display
                            display_name = feature.replace('_', ' ').replace('lag', 'Lag ').title()
                            ui.label(f"{display_name}: {importance:.1%}").classes('bg-gray-800 px-3 py-1 rounded text-sm text-gray-300')
            else:
                ui.label("⚠️ Could not generate prediction range").classes('text-yellow-400')
        else:
            with ui.row().classes('w-full'):
                ui.label("⚠️ Insufficient historical data for reliable ML prediction").classes('text-yellow-400')
                ui.label("Requires 50+ trading days with valid technical indicators").classes('text-gray-400 text-sm ml-4')
        
        # === AI MARKET ANALYSIS SECTION ===
        ui.separator().classes('bg-gray-700 my-6')
        ui.label('🧠 AI Market Analysis').classes('text-xl font-bold text-white mb-4')
        
        analysis_insights = stock_analyzer.generate_market_analysis(data_with_indicators, ticker)
        
        for i, insight in enumerate(analysis_insights):
            # Color-code based on sentiment indicators
            if any(x in insight for x in ['🚀', '🟢', '✅', '📈', '🛒', '💡']):
                ui.label(insight).classes('text-green-400 mb-2')
            elif any(x in insight for x in ['🔴', '🔻', '📉', '🚨']):
                ui.label(insight).classes('text-red-400 mb-2')
            elif any(x in insight for x in ['⚠️', '🟡', '⌛']):
                ui.label(insight).classes('text-yellow-400 mb-2')
            else:
                ui.label(insight).classes('text-gray-300 mb-2')

        # === FUNDAMENTAL HEALTH SECTION ===
        ui.separator().classes('bg-gray-700 my-6')
        ui.label('💰 Fundamental Health').classes('text-xl font-bold text-white mb-4')
        
        fundamentals = fundamental_metrics.get_key_metrics_summary(ticker)
        
        if fundamentals.get('error'):
            ui.label(f"Could not load fundamentals: {fundamentals['error']}").classes('text-yellow-400')
        else:
            with ui.row().classes('w-full gap-4 flex-wrap'):
                for card in fundamentals['cards']:
                    with ui.column().classes('metric-card flex-1 min-w-[140px]'):
                        ui.label(card['label']).classes('metric-label')
                        ui.label(str(card['value'])).classes('text-xl font-bold text-cyan-400')
        
        # === OPTIONS FLOW SECTION ===
        ui.separator().classes('bg-gray-700 my-6')
        ui.label('📊 Options Flow').classes('text-xl font-bold text-white mb-4')
        
        flow = options_flow.get_options_flow(ticker)
        
        if flow.get('error'):
            ui.label(f"Could not load options flow: {flow['error']}").classes('text-yellow-400')
        else:
            # === TOP ROW: IV and Max Pain ===
            with ui.row().classes('w-full gap-4 mb-4'):
                with ui.column().classes('metric-card flex-1'):
                    ui.label('Implied Volatility (ATM)').classes('metric-label')
                    iv = flow.get('iv')
                    ui.label(f"{iv:.1f}%" if iv else '-').classes('text-2xl font-bold text-cyan-400')
                    exp = flow.get('nearest_expiration', '')
                    ui.label(f"Nearest Exp: {exp}").classes('text-xs text-gray-400')
                
                with ui.column().classes('metric-card flex-1'):
                    ui.label('Maximum Pain').classes('metric-label')
                    max_pain = flow.get('max_pain')
                    ui.label(f"${max_pain:.2f}" if max_pain else '-').classes('text-2xl font-bold text-purple-400')
                    mp_exp = flow.get('nearest_expiration', '')
                    ui.label(f"For: {mp_exp}").classes('text-xs text-gray-400')
                
                with ui.column().classes('metric-card flex-1'):
                    ui.label('Current Price').classes('metric-label')
                    flow_price = flow.get('current_price', 0)
                    ui.label(f"${flow_price:.2f}" if flow_price else '-').classes('text-2xl font-bold text-white')
            
            # Max Pain Analysis Row
            max_pain = flow.get('max_pain')
            flow_price = flow.get('current_price', 0)
            if max_pain and flow_price:
                mp_diff = flow_price - max_pain
                mp_diff_pct = (mp_diff / max_pain) * 100
                mp_distance = abs(mp_diff)
                mp_distance_pct = abs(mp_diff_pct)
                
                # Determine direction and color
                if mp_diff > 0:
                    mp_direction = "⬇️ BELOW"
                    mp_dir_color = 'text-red-400'
                    mp_action = f"Price likely to pull DOWN toward ${max_pain:.2f}"
                    mp_bg = 'bg-red-900/30 border border-red-800'
                else:
                    mp_direction = "⬆️ ABOVE"
                    mp_dir_color = 'text-green-400'
                    mp_action = f"Price likely to pull UP toward ${max_pain:.2f}"
                    mp_bg = 'bg-green-900/30 border border-green-800'
                
                # Determine strength of gravitational pull
                if mp_distance_pct < 2:
                    mp_strength = "🎯 AT MAX PAIN"
                    mp_strength_desc = "Price near max pain - expiration pressure is neutral"
                    mp_bg = 'bg-gray-800 border border-gray-600'
                elif mp_distance_pct < 5:
                    mp_strength = "💪 STRONG PULL"
                    mp_strength_desc = "Close to max pain - high probability of convergence"
                elif mp_distance_pct < 10:
                    mp_strength = "📊 MODERATE PULL"
                    mp_strength_desc = "Watch for movement toward max pain into expiration"
                else:
                    mp_strength = "⚠️ EXTENDED"
                    mp_strength_desc = "Far from max pain - may not converge this expiration"
                
                with ui.row().classes('w-full gap-4 mb-4'):
                    with ui.column().classes(f'metric-card flex-1 {mp_bg}'):
                        ui.label('Max Pain Gravity').classes('metric-label')
                        ui.label(mp_strength).classes('text-lg font-bold text-white')
                        ui.label(mp_strength_desc).classes('text-xs text-gray-300')
                    
                    with ui.column().classes('metric-card flex-1'):
                        ui.label('Direction to Max Pain').classes('metric-label')
                        ui.label(f"{mp_direction} ${max_pain:.2f}").classes(f'text-lg font-bold {mp_dir_color}')
                        ui.label(f"Distance: ${mp_distance:.2f} ({mp_distance_pct:.1f}%)").classes('text-xs text-gray-400')
                    
                    with ui.column().classes('metric-card flex-1'):
                        ui.label('Expiration Outlook').classes('metric-label')
                        ui.label(mp_action).classes('text-sm text-white')
            
            # Sentiment Badge
            sentiment = flow['sentiment']
            sentiment_colors = {
                'STRONGLY BULLISH': 'bg-green-900 text-green-400',
                'BULLISH': 'bg-green-800 text-green-300',
                'BEARISH': 'bg-red-800 text-red-300',
                'STRONGLY BEARISH': 'bg-red-900 text-red-400'
            }
            
            with ui.row().classes('w-full gap-4 mb-4'):
                with ui.column().classes(f'metric-card flex-1 text-center {sentiment_colors.get(sentiment, "")}'):
                    ui.label('FLOW SENTIMENT').classes('metric-label')
                    ui.label(sentiment).classes('text-2xl font-bold')
                    ui.label(flow['sentiment_description']).classes('text-xs text-gray-300 mt-1')
            
            with ui.row().classes('w-full gap-4'):
                with ui.column().classes('metric-card flex-1'):
                    ui.label('Net Premium').classes('metric-label')
                    net_prem = flow['net_premium']
                    prem_color = 'text-green-400' if net_prem > 0 else 'text-red-400'
                    ui.label(format_premium(net_prem)).classes(f'text-xl font-bold {prem_color}')
                    ui.label('Call $ - Put $').classes('text-xs text-gray-400')
                
                with ui.column().classes('metric-card flex-1'):
                    ui.label('P/C Volume Ratio').classes('metric-label')
                    ui.label(f"{flow['pc_volume_ratio']:.2f}").classes('text-xl font-bold text-cyan-400')
                    ui.label(flow['volume_bias']).classes('text-xs text-gray-400')
                
                with ui.column().classes('metric-card flex-1'):
                    ui.label('P/C Premium Ratio').classes('metric-label')
                    ui.label(f"{flow['pc_premium_ratio']:.2f}").classes('text-xl font-bold text-cyan-400')
                    ui.label(flow['premium_bias']).classes('text-xs text-gray-400')
                
                with ui.column().classes('metric-card flex-1'):
                    ui.label('Unusual Activity').classes('metric-label')
                    unusual_total = flow['unusual_calls'] + flow['unusual_puts']
                    ui.label(f"{unusual_total}").classes('text-xl font-bold text-yellow-400' if unusual_total > 0 else 'text-xl font-bold text-gray-400')
                    ui.label(f"{flow['unusual_calls']} calls, {flow['unusual_puts']} puts").classes('text-xs text-gray-400')

        # === EXPORT / COPY SECTION ===
        ui.separator().classes('bg-gray-700 my-6')
        ui.label('📋 Export Technical Data').classes('text-xl font-bold text-white mb-4')
        
        # Build raw technical data export
        export_lines = []
        export_lines.append(f"# {ticker} Technical Data")
        export_lines.append(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        export_lines.append("")
        
        # Price Data
        export_lines.append("## Price")
        export_lines.append(f"Close: {price:.2f}")
        export_lines.append("")
        
        # Moving Averages
        export_lines.append("## Moving Averages")
        export_lines.append(f"SMA 200: {sma200:.2f}")
        export_lines.append(f"EMA 8: {e8:.2f}")
        export_lines.append(f"EMA 21: {e21:.2f}")
        export_lines.append(f"EMA 34: {e34:.2f}")
        export_lines.append(f"EMA 55: {e55:.2f}")
        export_lines.append(f"EMA 89: {e89:.2f}")
        
        # Additional MAs from data_with_indicators
        if 'SMA_20' in data_with_indicators.columns:
            sma20 = float(data_with_indicators['SMA_20'].iloc[-1])
            export_lines.append(f"SMA 20: {sma20:.2f}")
        if 'SMA_50' in data_with_indicators.columns:
            sma50 = float(data_with_indicators['SMA_50'].iloc[-1])
            export_lines.append(f"SMA 50: {sma50:.2f}")
        export_lines.append("")
        
        # RSI & Momentum Indicators
        export_lines.append("## Momentum Indicators")
        if 'RSI' in data_with_indicators.columns:
            rsi = float(data_with_indicators['RSI'].iloc[-1])
            export_lines.append(f"RSI (14): {rsi:.1f}")
        export_lines.append(f"Stochastic K (8,3,3): {stoch:.1f}")
        if 'Stoch_D' in data_with_indicators.columns:
            stoch_d = float(data_with_indicators['Stoch_D'].iloc[-1])
            export_lines.append(f"Stochastic D: {stoch_d:.1f}")
        export_lines.append("")
        
        # MACD
        export_lines.append("## MACD")
        if 'MACD' in data_with_indicators.columns:
            macd = float(data_with_indicators['MACD'].iloc[-1])
            export_lines.append(f"MACD: {macd:.4f}")
        if 'MACD_signal' in data_with_indicators.columns:
            macd_signal = float(data_with_indicators['MACD_signal'].iloc[-1])
            export_lines.append(f"MACD Signal: {macd_signal:.4f}")
        if 'MACD_histogram' in data_with_indicators.columns:
            macd_hist = float(data_with_indicators['MACD_histogram'].iloc[-1])
            export_lines.append(f"MACD Histogram: {macd_hist:.4f}")
        export_lines.append("")
        
        # Bollinger Bands
        export_lines.append("## Bollinger Bands (20,2)")
        if 'BB_upper' in data_with_indicators.columns:
            bb_upper = float(data_with_indicators['BB_upper'].iloc[-1])
            bb_middle = float(data_with_indicators['BB_middle'].iloc[-1])
            bb_lower = float(data_with_indicators['BB_lower'].iloc[-1])
            export_lines.append(f"Upper Band: {bb_upper:.2f}")
            export_lines.append(f"Middle Band: {bb_middle:.2f}")
            export_lines.append(f"Lower Band: {bb_lower:.2f}")
            bb_width = (bb_upper - bb_lower) / bb_middle * 100
            export_lines.append(f"Band Width: {bb_width:.2f}%")
        export_lines.append("")
        
        # Volatility & ATR
        export_lines.append("## Volatility")
        export_lines.append(f"ATR (14): {atr:.2f}")
        export_lines.append(f"ATR (55): {atr55:.2f}")
        export_lines.append(f"ATR14/ATR55 Ratio: {squeeze_ratio:.2f}")
        export_lines.append(f"Squeeze Status: {'SQUEEZED' if is_squeezed else 'Normal'}")
        if 'High_Low_Pct' in data_with_indicators.columns:
            hl_pct = float(data_with_indicators['High_Low_Pct'].iloc[-1])
            export_lines.append(f"Daily Range %: {hl_pct:.2f}%")
        export_lines.append("")
        
        # Volume
        export_lines.append("## Volume")
        vol = float(data['Volume'].iloc[-1])
        vol_avg = float(data['Volume'].rolling(20).mean().iloc[-1])
        vol_ratio = vol / vol_avg if vol_avg > 0 else 1
        export_lines.append(f"Today Volume: {vol:,.0f}")
        export_lines.append(f"20-Day Avg Volume: {vol_avg:,.0f}")
        export_lines.append(f"Volume Ratio: {vol_ratio:.2f}")
        export_lines.append("")
        
        # Price Position
        export_lines.append("## Price Position")
        fifty_two_high = float(data['High'].rolling(252).max().iloc[-1])
        fifty_two_low = float(data['Low'].rolling(252).min().iloc[-1])
        pct_from_high = ((price - fifty_two_high) / fifty_two_high) * 100
        pct_from_low = ((price - fifty_two_low) / fifty_two_low) * 100
        export_lines.append(f"52-Week High: {fifty_two_high:.2f}")
        export_lines.append(f"52-Week Low: {fifty_two_low:.2f}")
        export_lines.append(f"% From 52W High: {pct_from_high:.1f}%")
        export_lines.append(f"% From 52W Low: {pct_from_low:.1f}%")
        export_lines.append(f"EMA Stack: {'Bullish' if is_stacked else 'Disordered'}")
        export_lines.append(f"Above SMA 200: {'Yes' if price > sma200 else 'No'}")
        export_lines.append("")
        
        # Calculated Levels
        export_lines.append("## Calculated Levels")
        export_lines.append(f"Stop Loss (1.5 ATR): {stop_loss:.2f}")
        export_lines.append(f"Target 1 (1.2 ATR): {tp1:.2f}")
        export_lines.append(f"Target 2 (2.5 ATR): {tp2:.2f}")
        export_lines.append("")
        
        # Comprehensive Fundamentals
        full_fundamentals = fundamental_metrics.get_fundamental_metrics(ticker)
        if not full_fundamentals.get('error'):
            export_lines.append("## Company Info")
            export_lines.append(f"Name: {full_fundamentals.get('company_name', ticker)}")
            export_lines.append(f"Sector: {full_fundamentals.get('sector', '-')}")
            export_lines.append(f"Industry: {full_fundamentals.get('industry', '-')}")
            export_lines.append("")
            
            export_lines.append("## Valuation")
            export_lines.append(f"Market Cap: {full_fundamentals.get('market_cap', '-')}")
            export_lines.append(f"P/E Ratio (TTM): {full_fundamentals.get('pe_ratio', '-')}")
            export_lines.append(f"Forward P/E: {full_fundamentals.get('forward_pe', '-')}")
            export_lines.append(f"P/S Ratio: {full_fundamentals.get('ps_ratio', '-')}")
            export_lines.append(f"P/B Ratio: {full_fundamentals.get('pb_ratio', '-')}")
            export_lines.append(f"EV/EBITDA: {full_fundamentals.get('ev_ebitda', '-')}")
            export_lines.append(f"PEG Ratio: {full_fundamentals.get('peg_ratio', '-')}")
            export_lines.append("")
            
            export_lines.append("## Profitability")
            export_lines.append(f"Gross Margin: {full_fundamentals.get('gross_margin', '-')}")
            export_lines.append(f"Operating Margin: {full_fundamentals.get('operating_margin', '-')}")
            export_lines.append(f"Profit Margin: {full_fundamentals.get('profit_margin', '-')}")
            export_lines.append(f"ROE: {full_fundamentals.get('roe', '-')}")
            export_lines.append(f"ROA: {full_fundamentals.get('roa', '-')}")
            export_lines.append("")
            
            export_lines.append("## Financial Health")
            export_lines.append(f"Current Ratio: {full_fundamentals.get('current_ratio', '-')}")
            export_lines.append(f"Debt/Equity: {full_fundamentals.get('debt_to_equity', '-')}")
            export_lines.append(f"Total Debt: {full_fundamentals.get('total_debt', '-')}")
            export_lines.append(f"Total Cash: {full_fundamentals.get('total_cash', '-')}")
            export_lines.append(f"Free Cash Flow: {full_fundamentals.get('free_cash_flow', '-')}")
            export_lines.append(f"Operating Cash Flow: {full_fundamentals.get('operating_cash_flow', '-')}")
            export_lines.append("")
            
            export_lines.append("## Growth")
            export_lines.append(f"Revenue Growth: {full_fundamentals.get('revenue_growth', '-')}")
            export_lines.append(f"Earnings Growth: {full_fundamentals.get('earnings_growth', '-')}")
            export_lines.append(f"Revenue Per Share: {full_fundamentals.get('revenue_per_share', '-')}")
            export_lines.append("")
            
            export_lines.append("## Analyst Consensus")
            export_lines.append(f"Target Price: ${full_fundamentals.get('target_price', 0):.2f}" if full_fundamentals.get('target_price') else "Target Price: -")
            export_lines.append(f"Recommendation: {full_fundamentals.get('recommendation', '-')}")
            export_lines.append(f"Number of Analysts: {full_fundamentals.get('num_analysts', 0)}")
            export_lines.append("")
        
        # Recent Performance
        export_lines.append("## Recent Performance")
        if len(data) >= 5:
            change_1d = ((price - float(data['Close'].iloc[-2])) / float(data['Close'].iloc[-2])) * 100
            change_5d = ((price - float(data['Close'].iloc[-5])) / float(data['Close'].iloc[-5])) * 100
            export_lines.append(f"1-Day Change: {change_1d:+.2f}%")
            export_lines.append(f"5-Day Change: {change_5d:+.2f}%")
        if len(data) >= 21:
            change_1mo = ((price - float(data['Close'].iloc[-21])) / float(data['Close'].iloc[-21])) * 100
            export_lines.append(f"1-Month Change: {change_1mo:+.2f}%")
        if len(data) >= 63:
            change_3mo = ((price - float(data['Close'].iloc[-63])) / float(data['Close'].iloc[-63])) * 100
            export_lines.append(f"3-Month Change: {change_3mo:+.2f}%")
        export_lines.append("")
        
        # Options Data (if available)
        if not flow.get('error'):
            export_lines.append("## Options Data")
            export_lines.append(f"IV (ATM): {flow.get('iv', 0):.1f}%")
            export_lines.append(f"Max Pain: {flow.get('max_pain', 0):.2f}")
            export_lines.append(f"Current vs Max Pain: {((flow.get('current_price', 0) - flow.get('max_pain', 0)) / flow.get('max_pain', 1) * 100):.1f}%")
            export_lines.append(f"P/C Volume Ratio: {flow['pc_volume_ratio']:.2f}")
            export_lines.append(f"P/C Premium Ratio: {flow['pc_premium_ratio']:.2f}")
            export_lines.append(f"Call Volume: {flow['total_call_volume']:,}")
            export_lines.append(f"Put Volume: {flow['total_put_volume']:,}")
            export_lines.append(f"Net Premium: ${flow['net_premium']:,.0f}")
            export_lines.append(f"Unusual Calls: {flow['unusual_calls']}")
            export_lines.append(f"Unusual Puts: {flow['unusual_puts']}")
            export_lines.append(f"Sentiment: {flow['sentiment']}")
            export_lines.append("")
        
        export_text = '\n'.join(export_lines)
        
        # Copy/paste text area
        ui.label('Copy this analysis to use with NotebookLM or other tools:').classes('text-gray-400 text-sm mb-2')
        ui.textarea(value=export_text).props('dark outlined readonly').classes('w-full').style('height: 250px; font-family: monospace;')
        
        # Download button
        def download_analysis():
            filename = f"{ticker}_analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.md"
            ui.download(export_text.encode('utf-8'), filename)
        
        ui.button('📥 Download as Markdown', on_click=download_analysis).props('outline color=cyan').classes('mt-2')

# --- LAYOUT ---

with ui.left_drawer(value=True).classes('bg-gray-900 q-pa-md'):
    ui.label("📈 Momentum Phinance").classes('sidebar-title')
    
    ui.separator().classes('bg-gray-700 my-2')
    
    # Mode Selection - Radio buttons
    mode_select = ui.radio(
        ["Market Health", "Market Screens", "Weekly Options", "Wheel Screener", "Single Ticker Audit"], 
        value=state.mode
    ).props('dark dense').bind_value(state, 'mode')
    
    def on_mode_change(e):
        state.mode = e.value
        update_ui()
    
    mode_select.on_value_change(on_mode_change)
    
    ui.separator().classes('bg-gray-700 my-4')
    
    # Scanner Controls (Show for Market Screens mode only)
    with ui.column().bind_visibility_from(state, 'mode', lambda m: m == 'Market Screens'):
        
        # Strategy Dropdown
        with ui.column().classes('sidebar-section'):
            ui.label("Strategy").classes('section-label')
            strategy_select = ui.select(
                strategies.get_strategy_names(),
                value=state.selected_strategy,
                on_change=lambda e: setattr(state, 'selected_strategy', e.value)
            ).props('dark outlined dense').classes('w-full')
        
        # Dynamic Parameters based on selected strategy
        with ui.column().classes('sidebar-section') as params_container:
            ui.label("Filter Controls").classes('section-label')
            
            # Momentum with Pullback Strategy Params
            with ui.column().bind_visibility_from(state, 'selected_strategy', lambda s: s == 'Momentum with Pullback'):
                ui.label("ADX Range").classes('text-white text-sm')
                with ui.row().classes('w-full'):
                    min_adx = ui.number('Min', value=20.0).props('dark dense outlined step=1.0').classes('w-1/2')
                    max_adx = ui.number('Max', value=100.0).props('dark dense outlined step=1.0').classes('w-1/2')

                ui.label("Market Cap ($B)").classes('text-white text-sm mt-2')
                mega_cap = ui.switch('Include Mega Caps ($2T+)', value=True).props('dark dense')
                
                with ui.row().classes('w-full'):
                    min_mcap_b = ui.number('Min', value=0.0).props('dark dense outlined step=0.1').classes('w-1/2')
                    max_mcap_b = ui.number('Max', value=5000.0).props('dark dense outlined step=0.1').classes('w-1/2')
                    
                    def update_mega_cap(e):
                        if e.value:
                            max_mcap_b.value = 5000.0
                        else:
                            max_mcap_b.value = 2.0
                    mega_cap.on_value_change(update_mega_cap)

                ui.label("Stochastic (8,3,3)").classes('text-white text-sm mt-2')
                with ui.row().classes('w-full'):
                    min_stoch = ui.number('Min', value=0.0).props('dark dense outlined step=1.0').classes('w-1/2')
                    max_stoch = ui.number('Max', value=40.0).props('dark dense outlined step=1.0').classes('w-1/2')
            
            # Small Cap Multibaggers Params
            with ui.column().bind_visibility_from(state, 'selected_strategy', lambda s: s == 'Small Cap Multibaggers'):
                ui.label("Market Cap ($M)").classes('text-white text-sm')
                with ui.row().classes('w-full'):
                    min_mcap_m = ui.number('Min', value=10.0).props('dark dense outlined step=1.0').classes('w-1/2')
                    max_mcap_m = ui.number('Max', value=1000.0).props('dark dense outlined step=10.0').classes('w-1/2')

                ui.label("Gross Margin (%)").classes('text-white text-sm mt-2')
                with ui.row().classes('w-full'):
                    min_gm = ui.number('Min', value=30.0).props('dark dense outlined step=5.0').classes('w-1/2')
                    max_gm = ui.number('Max', value=100.0).props('dark dense outlined step=5.0').classes('w-1/2')

                ui.label("Revenue Growth 3Y (%)").classes('text-white text-sm mt-2')
                min_rev_growth = ui.number('Min', value=15.0).props('dark dense outlined step=1.0').classes('w-full')
                
        async def run_scanner():
            strategy = strategies.get_strategy_by_display_name(state.selected_strategy)
            ui.notify(f'Running {strategy.name} screen...', type='info')
            
            # Build params based on selected strategy
            if state.selected_strategy == 'Momentum with Pullback':
                params = {
                    'adx_min': min_adx.value,
                    'adx_max': max_adx.value,
                    'mcap_min_b': min_mcap_b.value,
                    'mcap_max_b': max_mcap_b.value,
                    'stoch_min': min_stoch.value,
                    'stoch_max': max_stoch.value,
                    'include_mega_caps': mega_cap.value
                }
            else:
                params = {
                    'mcap_min_m': min_mcap_m.value,
                    'mcap_max_m': max_mcap_m.value,
                    'gross_margin_min': min_gm.value,
                    'gross_margin_max': max_gm.value,
                    'revenue_growth_min': min_rev_growth.value
                }
            
            try:
                query = strategy.build_query(params)
                count, df = await asyncio.to_thread(query.get_scanner_data)
                
                if count > 0:
                    df = strategy.post_process(df)
                    state.scanner_results = df
                    ui.notify(f'Found {len(df)} matches.', type='positive')
                else:
                    state.scanner_results = pd.DataFrame()
                    ui.notify('No matches found meeting criteria.', type='warning')
            except Exception as e:
                ui.notify(f"Error running scanner: {e}", type='negative')
                print(f"Scanner Error: {e}")
            
            update_ui()

        # Display fixed criteria for selected strategy
        ui.separator().classes('bg-gray-700 my-4')
        ui.label('🔒 Fixed Criteria').classes('section-label')
        strategy = strategies.get_strategy_by_display_name(state.selected_strategy)
        if hasattr(strategy, 'get_fixed_criteria'):
            criteria = strategy.get_fixed_criteria()
            for criterion in criteria:
                ui.label(criterion).classes('text-xs text-gray-400 mb-1')
        
        ui.button('🚀 Run Screen', on_click=run_scanner).props('color=green').classes('mt-4 w-full')


# --- MAIN CONTENT ---
with ui.column().classes('w-full q-pa-md') as content_container:
    update_ui()


ui.run(title='Tao Integrated Terminal', dark=True, reload=True, port=8080)

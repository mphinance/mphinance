"""
Momentum with Pullback Strategy - TAO Multi-Timeframe EMA Stack
"""
from tradingview_screener import Query, col
from typing import Dict, Any, List
import pandas as pd
from .base import BaseStrategy


class MomentumStrategy(BaseStrategy):
    """TAO Multi-Timeframe EMA Stack with Pullback focus."""
    
    name = "Momentum with Pullback"
    description = "EMA stack alignment with ADX pullback (default <40)"
    
    select_columns = [
        'name', 'description', 'close', 'change', 
        'ADX', 'ATR', 'ATR|1W', 'average_volume_10d_calc', 'market_cap_basic',
        'Stoch.K', 'SMA50', 'EMA200',
        'EMA8', 'EMA21', 'EMA34', 'EMA55', 'EMA89',
        'EMA8|1W', 'EMA21|1W', 'EMA34|1W', 'EMA55|1W', 'EMA89|1W',
        'EMA8|1M', 'EMA21|1M', 'EMA34|1M', 'EMA55|1M', 'EMA89|1M',
        'SMA50|1W', 'EMA200|1W', 'SMA50|1M', 'EMA200|1M'
    ]
    
    def get_default_params(self) -> Dict[str, Any]:
        return {
            'adx_min': 20.0,
            'adx_max': 100.0,
            'mcap_min_b': 0.0,
            'mcap_max_b': 2.0,
            'stoch_min': 0.0,
            'stoch_max': 40.0,  # Default to 40 as requested
            'include_mega_caps': False
        }
    
    def get_param_config(self) -> List[Dict[str, Any]]:
        return [
            {'name': 'adx_range', 'label': 'ADX Range', 'type': 'range', 
             'fields': [('adx_min', 'Min'), ('adx_max', 'Max')]},
            {'name': 'mcap_range', 'label': 'Market Cap ($B)', 'type': 'range',
             'fields': [('mcap_min_b', 'Min'), ('mcap_max_b', 'Max')],
             'mega_cap_switch': True},
            {'name': 'stoch_range', 'label': 'Stochastic (8,3,3)', 'type': 'range',
             'fields': [('stoch_min', 'Min'), ('stoch_max', 'Max')]}
        ]
    
    def build_query(self, params: Dict[str, Any]) -> Query:
        adx_range = (params.get('adx_min', 20), params.get('adx_max', 100))
        mcap_min = params.get('mcap_min_b', 0) * 1_000_000_000
        mcap_max = params.get('mcap_max_b', 2) * 1_000_000_000
        if params.get('include_mega_caps'):
            mcap_max = 5_000_000_000_000
        mcap_range = (mcap_min, mcap_max)
        stoch_range = (params.get('stoch_min', 0), params.get('stoch_max', 40))
        
        query = (
            Query()
            .select(*self.select_columns)
            .where(
                # General Filters
                col('exchange').isin(['NASDAQ', 'NYSE', 'AMEX']),
                col('close') > 0.01,
                col('volume') >= 500_000,
                col('average_volume_10d_calc') > 500_000,
                
                # User Dynamic Range Filters
                col('ADX').between(adx_range[0], adx_range[1]),
                col('market_cap_basic').between(mcap_range[0], mcap_range[1]),
                col('Stoch.K').between(stoch_range[0], stoch_range[1]),

                # Strategy Constants (Locked)
                col('ATR') < col('ATR|1W'),
                col('SMA50') > col('EMA200'),
                col('SMA50|1W') > col('EMA200|1W'),
                col('SMA50|1M') > col('EMA200|1M'),

                col('EMA8') > col('EMA21'), col('EMA21') > col('EMA34'), 
                col('EMA34') > col('EMA55'), col('EMA55') > col('EMA89'),

                col('EMA8|1W') > col('EMA21|1W'), col('EMA21|1W') > col('EMA34|1W'), 
                col('EMA34|1W') > col('EMA55|1W'), col('EMA55|1W') > col('EMA89|1W'),

                col('EMA8|1M') > col('EMA21|1M'), col('EMA21|1M') > col('EMA34|1M'), 
                col('EMA34|1M') > col('EMA55|1M'), col('EMA55|1M') > col('EMA89|1M')
            )
            .limit(1000)
        )
        return query
    
    def post_process(self, df: pd.DataFrame) -> pd.DataFrame:
        if df.empty:
            return df
        # Only show stocks within 1 ATR of EMA21 (Not Overextended)
        df['dist_to_21'] = (df['close'] - df['EMA21']).abs()
        df = df[df['dist_to_21'] <= df['ATR']]
        df = df.rename(columns={'Stoch.K': 'Stoch_K', 'ATR|1W': 'ATR_1W'})
        df = df.fillna(0.0)
        return df
    
    def get_fixed_criteria(self) -> list:
        """Return list of fixed/locked strategy criteria for display."""
        return [
            "📊 US Exchanges Only (NYSE, NASDAQ, AMEX)",
            "💰 Volume ≥ 500K daily",
            "📈 EMA Stack Aligned (D/W/M): 8 > 21 > 34 > 55 > 89",
            "✅ Uptrend: SMA50 > EMA200 (D/W/M)",
            "🔋 Volatility Squeeze: ATR(14) < ATR(1W)",
            "🎯 Not Overextended: Price within 1 ATR of EMA21"
        ]

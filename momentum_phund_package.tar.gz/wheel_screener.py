"""
Wheel Screener - Cash Secured Puts Scanner for Small Accounts
Finds high-yield OTM put opportunities with flexible DTE windows.
"""

import pandas as pd
import numpy as np
import yfinance as yf
from tradingview_screener import Query, col
from datetime import datetime
from typing import Dict, Any, Optional, List


def run_tv_screen(config: Dict[str, Any]) -> pd.DataFrame:
    """
    Run TradingView screen for potential wheel candidates.
    
    Config should contain:
        - min_price, max_price: Stock price range
        - min_volume: Minimum 30-day avg volume
        - max_adx: Maximum ADX (low = choppy/sideways, good for wheel)
        - min_rsi, max_rsi: RSI range
        - min_vol_m: Minimum monthly volatility %
    """
    where_clauses = [
        col('exchange') != "OTC",
        col('close').between(config['min_price'], config['max_price']),
        col('average_volume_30d_calc') > config['min_volume'],
        col('ADX').between(0, config['max_adx']), 
        col('RSI').between(config['min_rsi'], config['max_rsi']),
        col('Volatility.M') > config['min_vol_m'],
    ]
    
    query = (
        Query().select(
            'name', 'close', 'market_cap_basic', 'average_volume_30d_calc',
            'ADX', 'RSI', 'sector', 'industry', 'Volatility.M'
        )
        .where(*where_clauses)
        .set_markets('america')
        .limit(100)
    )
    
    try:
        _, df = query.get_scanner_data()
        if df.empty:
            return pd.DataFrame()
        
        df = df.rename(columns={
            'name': 'symbol',
            'close': 'price', 
            'market_cap_basic': 'market_cap',
            'average_volume_30d_calc': 'avg_volume', 
            'ADX': 'adx',
            'RSI': 'rsi', 
            'Volatility.M': 'volatility_month'
        })
        return df
    except Exception as e:
        print(f"TradingView Error: {e}")
        return pd.DataFrame()


def fetch_wheel_data(symbol: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Fetch options data for a symbol and find the best CSP opportunity.
    
    Config should contain:
        - dte_range: tuple of (min_dte, max_dte)
        - max_capital: Maximum capital per contract
    """
    try:
        stock = yf.Ticker(symbol)
        info = stock.info
        price = info.get('currentPrice') or info.get('regularMarketPrice')
        if not price:
            return None
        
        div_yield = info.get('dividendYield', 0)
        div_yield = (div_yield * 100) if div_yield else 0
        
        expirations = stock.options
        if not expirations:
            return None
        
        today = datetime.now()
        min_dte, max_dte = config['dte_range']
        
        # Filter expirations that fit the DTE window
        valid_exps = []
        for exp in expirations:
            dte = (datetime.strptime(exp, '%Y-%m-%d') - today).days
            if min_dte <= dte <= max_dte:
                valid_exps.append((exp, dte))
        
        if not valid_exps:
            return None
            
        # Select the first valid expiration in the window
        target_exp, dte = valid_exps[0]
        
        chain = stock.option_chain(target_exp).puts
        
        # OTM Put Filter (Looking for ~10% OTM by default, range 5-25% OTM)
        puts = chain[
            (chain['strike'] >= price * 0.75) & 
            (chain['strike'] <= price * 0.95) & 
            (chain['bid'] > 0)
        ]
        if puts.empty:
            return None
        
        # Select strike closest to 10% OTM
        puts = puts.copy()
        puts['diff'] = abs(puts['strike'] - (price * 0.90))
        best = puts.loc[puts['diff'].idxmin()]
        
        capital_outlay = best['strike'] * 100
        if capital_outlay > config['max_capital']:
            return None

        mid = (best['bid'] + best['ask']) / 2
        roc_period = (mid / best['strike']) * 100
        
        # Calculate Weekly ROC
        weeks = max(dte, 1) / 7.0
        roc_weekly = roc_period / weeks

        iv = best['impliedVolatility'] * 100
        
        return {
            'symbol': symbol,
            'current_price': price,
            'strike': best['strike'],
            'capital_required': capital_outlay,
            'dte': dte,
            'iv': iv, 
            'mid': mid,
            'roc_period': roc_period,
            'roc_weekly': roc_weekly,
            'div_yield': div_yield,
            'expiration': target_exp
        }
    except Exception as e:
        print(f"Error fetching wheel data for {symbol}: {e}")
        return None


def run_wheel_scan(config: Dict[str, Any], progress_callback=None) -> pd.DataFrame:
    """
    Run the full wheel scan: TradingView screen -> Options analysis.
    
    Args:
        config: Configuration dict with all filter settings
        progress_callback: Optional callback(current, total) for progress updates
    
    Returns:
        DataFrame with wheel opportunities sorted by score
    """
    # Step 1: Get TradingView candidates
    tv_df = run_tv_screen(config)
    
    if tv_df.empty:
        return pd.DataFrame()
    
    # Step 2: Analyze options for each candidate
    max_results = config.get('max_results', 20)
    min_roc_req = config.get('min_roc_weekly', 1.0)
    
    wheel_results = []
    
    # Iterate through candidates until we find enough results or run out of candidates
    # Add a safety limit (e.g. check at most 50 candidates) to prevent excessive runtimes
    max_checks = 50 
    checked_count = 0
    
    for i, row in tv_df.iterrows():
        if len(wheel_results) >= max_results:
            break
            
        if checked_count >= max_checks:
            break
            
        sym = row['symbol']
        
        if progress_callback:
            progress_callback(i + 1, len(tv_df))
            
        data = fetch_wheel_data(sym, config)
        if data and data['roc_weekly'] >= min_roc_req:
            wheel_results.append(data)
            
        checked_count += 1
    
    if not wheel_results:
        return pd.DataFrame()
    
    # Step 3: Merge with TradingView data and score
    final_df = pd.DataFrame(wheel_results)
    final_df = final_df.merge(
        tv_df[['symbol', 'sector', 'adx', 'rsi']], 
        on='symbol',
        how='left'
    )
    
    # Weighted Scoring: higher ROC, dividend good; high RSI less attractive
    final_df['score'] = (
        (final_df['roc_weekly'] * 20) + 
        (final_df['div_yield'] * 5) - 
        (final_df['rsi'] * 0.1)
    )
    final_df = final_df.sort_values('score', ascending=False)
    
    return final_df


def get_default_config() -> Dict[str, Any]:
    """Get default configuration for wheel screener."""
    return {
        # DTE settings
        'dte_range': (30, 45),  # Monthly
        'max_capital': 500,
        
        # Price filters
        'min_price': 1.0,
        'max_price': 5.0,
        
        # Technical filters
        'max_adx': 85,
        'min_rsi': 20,
        'max_rsi': 85,
        'min_vol_m': 1.0,
        'min_volume': 150_000,
        
        # Yield requirements
        'min_roc_weekly': 1.0,
        'max_results': 20,
    }


if __name__ == '__main__':
    print("Testing Wheel Screener...")
    config = get_default_config()
    config['max_results'] = 5  # Limit for testing
    
    def progress(current, total):
        print(f"  Analyzing {current}/{total}...")
    
    results = run_wheel_scan(config, progress)
    
    if results.empty:
        print("No results found.")
    else:
        print(f"\nFound {len(results)} opportunities:\n")
        print(results[['symbol', 'strike', 'capital_required', 'dte', 'roc_weekly', 'score']].to_string())
